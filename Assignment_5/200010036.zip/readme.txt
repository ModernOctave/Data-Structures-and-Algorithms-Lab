To compile the program run the following command in the directory with 200010036.c, ll.c and ll.h,

gcc 200010036.c ll.c


To name the executable you can add the -o flag,

gcc 200010036.c ll.c -o <executable-name>