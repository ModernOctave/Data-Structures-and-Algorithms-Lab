int is_queue_empty(struct node *head);
struct node *enqueue(struct node *head, int data);
struct node *dequeue(struct node *head, int *data);